#!/bin/bash

MUSIC_DIR="${1:-.}"

shopt -s nullglob
files=( "$MUSIC_DIR"/*.wav )

total=${#files[@]}
page=0
selected=""
pid=""
duration=0
start_time=0

format_time() {
    printf "%02d:%02d" "$(( $1 / 60 ))" "$(( $1 % 60 ))"
}

while true; do
    clear

    start=$((page * 9))
    end=$((start + 9))

    for ((i=start; i<end && i<total; i++)); do
        index=$((i - start))

        if [[ "$selected" == "$i" ]]; then
            printf "[X] %d. %s\n" "$((index + 1))" "$(basename "${files[$i]}")"
        else
            printf "[ ] %d. %s\n" "$((index + 1))" "$(basename "${files[$i]}")"
        fi
    done

    current=0

    if [[ -n "$selected" ]] && kill -0 "$pid" 2>/dev/null; then
        current=$((SECONDS - start_time))
        (( current > duration )) && current=$duration
    fi

    printf "\nСтраница %d/%d — %s/%s\n" \
        "$((page + 1))" "$(( (total + 8) / 9 ))" \
        "$(format_time "$current")" "$(format_time "$duration")"

    IFS= read -rsn1 -t 1 key

    if [[ "$key" == $'\x1b' ]]; then
        read -rsn1 -t 0.1 key
        if [[ "$key" == "[" ]]; then
            read -rsn1 -t 0.1 key

            if [[ "$key" == "C" && $((start + 9)) -lt "$total" ]]; then
                ((page++))
            elif [[ "$key" == "D" && "$page" -gt 0 ]]; then
                ((page--))
            fi
        fi

    elif [[ "$key" =~ [1-9] ]]; then
        index=$((start + key - 1))

        if (( index < total )); then
            if [[ "$selected" == "$index" ]]; then
                kill "$pid" 2>/dev/null
                selected=""
                pid=""
                duration=0
            else
                kill "$pid" 2>/dev/null

                duration=$(ffprobe -v error \
                    -show_entries format=duration \
                    -of default=noprint_wrappers=1:nokey=1 \
                    "${files[$index]}" 2>/dev/null)

                duration=${duration%.*}
                [[ "$duration" =~ ^[0-9]+$ ]] || duration=0

                aplay "${files[$index]}" >/dev/null 2>&1 &
                pid=$!
                selected="$index"
                start_time=$SECONDS
            fi
        fi
    fi

    if [[ -n "$selected" ]] && ! kill -0 "$pid" 2>/dev/null; then
        selected=""
        pid=""
        duration=0
    fi
done